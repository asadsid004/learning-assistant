import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getKindeServerSession } from "@kinde-oss/kinde-auth-nextjs/server";

export async function GET() {
  try {


    const quizzes = await prisma.quiz.findMany({
      where: { userId: "1", attempted: true },
      select: {
        id: true,
        title: true,
        score: true,
      },
      orderBy: { createdAt: "asc" },
    });

    // Add an index for ordering in the chart
    const indexedQuizzes = quizzes.map((quiz, index) => ({
      quizIndex: index + 1,
      ...quiz,
    }));

    return NextResponse.json(indexedQuizzes);
  } catch (error) {
    console.error("Failed to fetch quiz scores:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
